from PySide2.QtWidgets import QMainWindow


from tallenna import Ui_Tallenna


class Tallenna_gui(QMainWindow,Ui_Tallenna):
    def __init__(self):
        super().__init__()

    #Lisää objektit ruudulle määritelty levyrekisteri luokassa
        self.setupUi(self)
        #Mitä pitää laittaa että saa näkyviin tallenna.py formin?



       